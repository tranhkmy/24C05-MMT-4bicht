﻿//using Microsoft.AspNetCore.StaticFiles; // ⬅️ Cần thư viện này cho FileExtensionContentTypeProvider
//using Microsoft.Extensions.FileProviders; // ⬅️ Cần thư viện này

using RemoteControlApiBridge.Services;

var builder = WebApplication.CreateBuilder(args);

// Thêm CORS để Frontend có thể gọi API
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy",
        builder =>
        {
            builder.AllowAnyOrigin() // Cho phép từ mọi nguồn (an toàn trong mạng LAN)
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});

// Thêm Services và Controllers
builder.Services.AddControllers();
builder.Services.AddSingleton<RemoteControlService>(); // Đăng ký dịch vụ Socket

var app = builder.Build();

// -----------------------------------------------------------
// 🚨 PHẦN CẬP NHẬT: Xóa bỏ code cũ và dùng chuẩn wwwroot
// -----------------------------------------------------------

// 1. Kích hoạt phục vụ các file tĩnh (HTML, JS, CSS) từ thư mục wwwroot
// Lệnh này đã bao gồm cả việc tự động phục vụ index.html
app.UseStaticFiles();

// 2. Định tuyến mặc định (Giúp index.html tự động tải khi truy cập /)
app.UseDefaultFiles(); // Cần thiết để chỉ định index.html là file mặc định

// -----------------------------------------------------------

app.UseCors("CorsPolicy"); // Sử dụng CORS

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();