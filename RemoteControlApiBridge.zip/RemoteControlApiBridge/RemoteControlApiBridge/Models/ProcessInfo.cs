﻿namespace RemoteControlApiBridge.Models
{
    public class ProcessInfo
    {
        public int Id { get; set; } // Process ID (PID)
        public string Name { get; set; } // Tên Process
        public string Title { get; set; } // Tên Cửa sổ (nếu có)
    }

    // Model dùng cho lệnh START/KILL từ Frontend
    public class ProcessActionRequest
    {
        public int Id { get; set; }
        public string Path { get; set; } // Dùng cho Start App
    }
}