﻿using Microsoft.AspNetCore.Mvc;
using RemoteControlApiBridge.Services;
using RemoteControlApiBridge.Models;

[ApiController]
[Route("api/[controller]")]
public class ControlController : ControllerBase
{
    private readonly RemoteControlService _service;

    public ControlController(RemoteControlService service)
    {
        _service = service;
    }

    // Lấy danh sách Processes
    // GET: /api/Control/processes
    [HttpGet("processes")]
    public ActionResult<IEnumerable<ProcessInfo>> GetProcesses()
    {
        try
        {
            var processes = _service.ListProcesses();
            return Ok(processes);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Message = "Failed to list processes", Error = ex.Message });
        }
    }

    // 🚨 ENDPOINT MỚI: Lấy danh sách Ứng dụng 🚨
    // GET: /api/Control/apps
    [HttpGet("apps")]
    public ActionResult<IEnumerable<ProcessInfo>> GetApps()
    {
        try
        {
            var apps = _service.ListApps();
            return Ok(apps);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Message = "Failed to list applications", Error = ex.Message });
        }
    }

    // Dừng Process
    // POST: /api/Control/kill
    [HttpPost("kill")]
    public IActionResult KillProcess([FromBody] ProcessActionRequest request)
    {
        if (request.Id == 0) return BadRequest(new { Message = "Process ID is required." });

        try
        {
            string result = _service.KillProcess(request.Id);
            if (result.StartsWith("ERROR"))
            {
                return BadRequest(new { Message = "Action failed", Detail = result });
            }
            return Ok(new { Message = "Process killed successfully", Detail = result });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Message = "Internal server error", Error = ex.Message });
        }
    }

    // Khởi động Ứng dụng
    // POST: /api/Control/start
    [HttpPost("start")]
    public IActionResult StartApp([FromBody] ProcessActionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Path)) return BadRequest(new { Message = "Application path is required." });

        try
        {
            string result = _service.StartProcess(request.Path);
            if (result.StartsWith("ERROR"))
            {
                return BadRequest(new { Message = "Action failed", Detail = result });
            }
            return Ok(new { Message = "Application started successfully", Detail = result });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { Message = "Internal server error", Error = ex.Message });
        }
    }
}