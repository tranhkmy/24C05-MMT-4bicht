﻿using RemoteControlApiBridge.Models;
using System.Net.Sockets;
using System.Text;

namespace RemoteControlApiBridge.Services
{
    public class RemoteControlService
    {
        private readonly string _serverIp;
        private readonly int _serverPort;

        public RemoteControlService(IConfiguration config)
        {
            // Lấy cấu hình IP/Port từ appsettings.json
            _serverIp = config["ServerSettings:IpAddress"] ?? "127.0.0.1";
            _serverPort = config.GetValue<int>("ServerSettings:Port") == 0 ? 5656 : config.GetValue<int>("ServerSettings:Port");
        }

        /**
         * Hàm cốt lõi: Kết nối, gửi lệnh và nhận phản hồi từ Server Socket
         */
        //private string SendCommand(string command)
        //{
        //    try
        //    {
        //        // Thay thế việc dùng Socket trong WinForm bằng TcpClient
        //        using var client = new TcpClient(_serverIp, _serverPort);

        //        // 🚨 THÊM CẤU HÌNH TIMEOUT 🚨
        //        //client.SendTimeout = 10000; // 10 giây cho gửi
        //        //client.ReceiveTimeout = 10000; // 10 giây cho nhận

        //        using var stream = client.GetStream();

        //        // 1. Gửi lệnh (ví dụ: "LIST_PROCESS\n")
        //        byte[] commandBytes = Encoding.UTF8.GetBytes(command + "\n");
        //        stream.Write(commandBytes, 0, commandBytes.Length);

        //        // 2. Nhận phản hồi (Đọc toàn bộ dữ liệu cho đến khi Server Socket đóng)
        //        var responseBuilder = new StringBuilder();
        //        byte[] buffer = new byte[1024]; // Giảm kích thước buffer
        //        int bytesRead;

        //        // Đọc dữ liệu cho đến khi hết (stream.Read trả về 0) hoặc timeout xảy ra
        //        // Lưu ý: Việc này yêu cầu Server Socket PHẢI ĐÓNG kết nối sau khi gửi dữ liệu!
        //        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
        //        {
        //            responseBuilder.Append(Encoding.UTF8.GetString(buffer, 0, bytesRead));
        //        }

        //        return responseBuilder.ToString().Trim();
        //    }
        //    catch (Exception ex)
        //    {
        //        return $"ERROR: Connection failed or command error: {ex.Message}";
        //    }
        //}

        private string SendCommand(string command)
        {
            try
            {
                using var client = new TcpClient(_serverIp, _serverPort);

                client.SendTimeout = 10000;
                client.ReceiveTimeout = 10000;

                using var stream = client.GetStream();
                // SỬ DỤNG STREAMREADER/STREAMWRITER ĐỂ XỬ LÝ DÒNG
                using var writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };
                using var reader = new StreamReader(stream, Encoding.UTF8);

                // 1. Gửi lệnh
                writer.WriteLine(command);

                string rawResponse;

                // LIST_PROCESS/LIST_APP: Đọc cho đến khi hết stream
                if (command.StartsWith("LIST_PROCESS") || command.StartsWith("LIST_APP"))
                {
                    var responseBuilder = new StringBuilder();
                    while (!reader.EndOfStream)
                    {
                        responseBuilder.AppendLine(reader.ReadLine());
                    }
                    rawResponse = responseBuilder.ToString();
                }
                else
                {
                    // 🚨 KILL/START: Đọc DÒNG đầu tiên và chỉ DÒNG đó. 🚨
                    // Đảm bảo không bị treo nếu Server Socket không đóng kết nối ngay sau lệnh.
                    rawResponse = reader.ReadLine();
                }

                client.Close();

                // Trả về chuỗi phản hồi (nếu là null, trả về lỗi rõ ràng)
                return rawResponse?.Trim() ?? "ERROR: Phản hồi RỖNG hoặc Socket bị đóng không có dữ liệu.";
            }
            catch (Exception ex)
            {
                return $"ERROR: Connection failed or command error: {ex.Message}";
            }
        }

        public List<ProcessInfo> ListProcesses()
        {
            string rawResponse = SendCommand("LIST_PROCESS");
            if (rawResponse.StartsWith("ERROR")) throw new Exception(rawResponse);

            var processes = new List<ProcessInfo>();

            // Phân tích chuỗi phản hồi: "Id|Name|Title\n..."
            var lines = rawResponse.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length >= 2 && int.TryParse(parts[0], out int id))
                {
                    processes.Add(new ProcessInfo
                    {
                        Id = id,
                        Name = parts[1].Trim(),
                        Title = parts.Length > 2 ? parts[2].Trim() : ""
                    });
                }
            }
            return processes;
        }

        // 🚨 HÀM MỚI: Lấy danh sách Ứng dụng (App) 🚨
        public List<ProcessInfo> ListApps()
        {
            string rawResponse = SendCommand("LIST_APP");
            if (rawResponse.StartsWith("ERROR")) throw new Exception(rawResponse);

            var apps = new List<ProcessInfo>();
            var lines = rawResponse.Split('\n', StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length >= 2 && int.TryParse(parts[0], out int id))
                {
                    apps.Add(new ProcessInfo
                    {
                        Id = id,
                        Name = parts[1].Trim(),
                        Title = parts.Length > 2 ? parts[2].Trim() : ""
                    });
                }
            }
            return apps;
        }

        public string KillProcess(int processId)
        {
            string command = $"KILL_PROCESS {processId}";
            return SendCommand(command);
        }

        public string StartProcess(string appPath)
        {
            string command = $"START_PROCESS {appPath}";
            return SendCommand(command);
        }
    }
}