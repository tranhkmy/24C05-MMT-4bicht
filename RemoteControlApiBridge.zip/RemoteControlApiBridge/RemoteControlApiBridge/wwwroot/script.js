﻿// CẤU HÌNH: Thay bằng IP và Port thực tế của máy chạy API Bridge
const API_BASE_URL = '/api/Control';

function displayMessage(message, type) {
    const msgElement = document.getElementById('message');
    msgElement.textContent = message;
    msgElement.className = `alert alert-${type}`;
    msgElement.classList.remove('d-none');
    setTimeout(() => {
        msgElement.classList.add('d-none');
    }, 5000);
}

/**
 * Gửi yêu cầu lấy danh sách Processes qua API Bridge
 */
async function listProcesses() {
    const tableBody = document.getElementById('processTableBody');
    const spinner = document.getElementById('list-spinner');

    tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Đang tải...</td></tr>';
    spinner.classList.remove('d-none');

    try {
        const response = await fetch(`${API_BASE_URL}/processes`);
        const data = await response.json();

        if (!response.ok) {
            displayMessage(`Lỗi: ${data.Error || data.Message}`, 'danger');
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Không thể kết nối đến Server hoặc API Bridge.</td></tr>';
            return;
        }

        renderProcesses(data);
        displayMessage(`Tải thành công ${data.length} Processes.`, 'success');

    } catch (error) {
        displayMessage(`Lỗi kết nối: Không thể gọi API Bridge. Vui lòng kiểm tra API Bridge có đang chạy không.`, 'danger');
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Lỗi kết nối đến API Bridge.</td></tr>';
    } finally {
        spinner.classList.add('d-none');
    }
}

/**
 * 🚨 HÀM MỚI: Gửi yêu cầu lấy danh sách Ứng dụng (App) 🚨
 */
async function listApps() {
    const tableBody = document.getElementById('processTableBody');
    const spinner = document.getElementById('list-spinner');

    tableBody.innerHTML = '<tr><td colspan="3" class="text-center">Đang tải Apps...</td></tr>';
    spinner.classList.remove('d-none');

    try {
        // GỌI ENDPOINT /apps MỚI
        const response = await fetch(`${API_BASE_URL}/apps`);
        const data = await response.json();

        if (!response.ok) {
            displayMessage(`Lỗi: ${data.Error || data.Message}`, 'danger');
            tableBody.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Không thể kết nối hoặc Server lỗi.</td></tr>';
            return;
        }

        renderProcesses(data);
        displayMessage(`Tải thành công ${data.length} Ứng dụng có cửa sổ.`, 'success');

    } catch (error) {
        displayMessage(`Lỗi kết nối: Không thể gọi API Bridge.`, 'danger');
        tableBody.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Lỗi kết nối đến API Bridge.</td></tr>';
    } finally {
        spinner.classList.add('d-none');
    }
}

/**
 * Vẽ danh sách Processes lên bảng
 */
function renderProcesses(processes) {
    const tableBody = document.getElementById('processTableBody');
    tableBody.innerHTML = '';

    if (processes.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Không tìm thấy Process nào.</td></tr>';
        return;
    }

    processes.forEach(p => {
        const row = tableBody.insertRow();
        row.insertCell().textContent = p.id;
        row.insertCell().textContent = p.name;
        row.insertCell().textContent = p.title || "(N/A)";

        const actionCell = row.insertCell();
        const killButton = document.createElement('button');
        killButton.className = 'btn btn-sm btn-danger';
        killButton.textContent = 'Stop/Kill';
        killButton.onclick = () => killProcess(p.id, p.name);
        actionCell.appendChild(killButton);
    });
}

/**
 * Gửi yêu cầu dừng (Kill) Process
 */
//async function killProcess(id, name) {
//    if (!confirm(`Bạn có chắc chắn muốn dừng Process: ${name} (PID: ${id})?`)) return;

//    try {
//        const response = await fetch(`${API_BASE_URL}/kill`, {
//            method: 'POST',
//            headers: { 'Content-Type': 'application/json' },
//            body: JSON.stringify({ id: id })
//        });
//        const data = await response.json();

//        if (response.ok) {
//            displayMessage(`Đã dừng Process thành công: ${name}.`, 'success');
//            listProcesses();
//        } else {
//            displayMessage(`Lỗi khi dừng Process ${name}: ${data.Detail || data.Message}`, 'danger');
//        }

//    } catch (error) {
//        displayMessage(`Lỗi kết nối API Bridge: ${error.message}`, 'danger');
//    }
//}

async function killProcessById() {
    const idInput = document.getElementById('processIdInput');
    const processId = parseInt(idInput.value.trim());

    if (isNaN(processId) || processId <= 0) {
        displayMessage("Vui lòng nhập Process ID (PID) hợp lệ.", 'warning');
        return;
    }

    if (!confirm(`Bạn có chắc chắn muốn dừng Process với PID: ${processId}?`)) return;

    try {
        const response = await fetch(`${API_BASE_URL}/kill`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            // API Bridge (ControlController.cs) mong muốn ID trong body
            body: JSON.stringify({ id: processId })
        });
        const data = await response.json();

        if (response.ok) {
            displayMessage(`Đã dừng Process ID ${processId} thành công.`, 'success');
            listProcesses();
        } else {
            // 🚨 SỬA LỖI HIỂN THỊ UNDEFINED 🚨
            // Hiển thị data.Detail nếu có, hoặc Message, hoặc thông báo chung
            const errorMessage = data.Detail || data.Message || `Phản hồi lỗi không xác định. Mã lỗi: ${response.status}`;
            // Hiển thị chi tiếlỗi từ Server Socket (ví dụ: Access is denied)
            displayMessage(`Lỗi khi dừng Process ${processId}: ${data.Detail || data.Message}`, 'danger');
        }

    } catch (error) {
        displayMessage(`Lỗi kết nối API Bridge: ${error.message}`, 'danger');
    }
}

/**
 * Gửi yêu cầu khởi động (Start) App
 */
async function startApp() {
    const appPath = document.getElementById('appPathInput').value.trim();
    if (!appPath) {
        displayMessage("Vui lòng nhập đường dẫn ứng dụng để khởi động.", 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: appPath })
        });
        const data = await response.json();

        if (response.ok) {
            displayMessage(`Đã khởi động ứng dụng thành công: ${appPath}.`, 'success');
        } else {
            displayMessage(`Lỗi khi khởi động ứng dụng ${appPath}: ${data.Detail || data.Message}`, 'danger');
        }

    } catch (error) {
        displayMessage(`Lỗi kết nối API Bridge: ${error.message}`, 'danger');
    }
}

// Gọi listProcesses khi trang web được tải
window.onload = listProcesses;